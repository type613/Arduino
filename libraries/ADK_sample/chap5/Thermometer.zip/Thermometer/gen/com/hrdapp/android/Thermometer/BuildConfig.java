/** Automatically generated file. DO NOT MODIFY */
package com.hrdapp.android.Thermometer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}