package com.hrdapp.android.Thermometer;

import java.text.DecimalFormat;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class ThermometerActivity extends Activity {
	private final static int USBAccessoryWhat = 0;

	public static final int SET_LED		 	= 1;
	public static final int REQUEST_AD		= 2;
	public static final int RESPONSE_AD		= 3;
	public static final int APP_CONNECT		= (int)0xFE;
	public static final int APP_DISCONNECT	= (int)0xFF;

	private boolean deviceAttached = false;

	private String TAG = "Thermometer";

	private enum ErrorMessageCode {
		ERROR_OPEN_ACCESSORY_FRAMEWORK_MISSING,
		ERROR_FIRMWARE_PROTOCOL
	};

	private USBAccessoryManager accessoryManager; 

	Timer updateTimer = null;

	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

		setContentView(R.layout.main);

        accessoryManager = new USBAccessoryManager(handler, USBAccessoryWhat);
   }
	
	@Override
	public void onStart() {
		super.onStart();
		
	    if(checkForOpenAccessoryFramework() == false){
	    	showErrorPage(ErrorMessageCode.ERROR_OPEN_ACCESSORY_FRAMEWORK_MISSING);
	    	return;
	    } 
	    
		this.setTitle("Thermometer : Device not connected.");

		DecimalFormat tFormat = new DecimalFormat("###");
    	TextView temp_text = (TextView)findViewById(R.id.temp);
    	temp_text.setText(tFormat.format(0) + "゜");
	}
	
    @Override
    public void onResume() {
    	super.onResume();
    	
	    if(checkForOpenAccessoryFramework() == false){
	    	showErrorPage(ErrorMessageCode.ERROR_OPEN_ACCESSORY_FRAMEWORK_MISSING);
	    	return;
	    } 
	    
        accessoryManager.enable(this, getIntent());
        
        // タイマーを設定 (2)
    	if(updateTimer == null)
        {
        	updateTimer = new Timer(true);
	        updateTimer.scheduleAtFixedRate( new TimerTask(){
	            @Override
	            public void run() {
	        		Message Update = Message.obtain(handler, REQUEST_AD);
	        		
	        		if(handler != null) {
	        			// コマンド送信
	        			handler.sendMessage(Update);
	        		}	            	
	            }
	        }, 500, 1000);
        }
    }
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
    	if(deviceAttached == false){
    		return;
    	}
    	
	    if(checkForOpenAccessoryFramework() == false){
	    	showErrorPage(ErrorMessageCode.ERROR_OPEN_ACCESSORY_FRAMEWORK_MISSING);
			//Call the super function that we are over writing now that we have saved our data.
			super.onSaveInstanceState(savedInstanceState);
	    	return;
	    } 
		
		//Call the super function that we are over writing now that we have saved our data.
		super.onSaveInstanceState(savedInstanceState);
    }

    private boolean checkForOpenAccessoryFramework(){
	    try {
	    	@SuppressWarnings({ "unused", "rawtypes" })
			Class s = Class.forName("com.android.future.usb.UsbManager");
	    	s = Class.forName("com.android.future.usb.UsbAccessory");
	    } catch (ClassNotFoundException e) {
	    	Log.d("ClassNotFound",e.toString());
	    	return false;
	    }
	    return true;
    }

    @Override
    public void onPause() {
	    if(checkForOpenAccessoryFramework() == false){
	    	showErrorPage(ErrorMessageCode.ERROR_OPEN_ACCESSORY_FRAMEWORK_MISSING);
	    	super.onPause();
	    	return;
	    } 

	    updateTimer.cancel();
    	updateTimer = null;
	    
		byte[] commandPacket = new byte[2];
		commandPacket[0] = (byte) APP_DISCONNECT;
		commandPacket[1] = 0;
		accessoryManager.write(commandPacket);	
	    
		try {
			while(accessoryManager.isClosed() == false) {
				Thread.sleep(2000);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
    	super.onPause();
    	accessoryManager.disable(this);
    	disconnectAccessory();
    }

    /** Resets the demo application when a device detaches 
     */
    public void disconnectAccessory() {
    	if(deviceAttached == false) {
    		return;
    	}
    	
    	Log.d(TAG,"disconnectAccessory()");
    	
    	this.setTitle("Thermometer : Device not connected.");

    }
    /** 
     * Handler for receiving messages from the USB Manager thread or
     *   the LED control modules
     */
    private Handler handler = new Handler() {
    	@Override
    	public void handleMessage(Message msg) {
    		byte[] commandPacket = new byte[2];
    		
			switch(msg.what)
			{				
			case SET_LED:
				if(accessoryManager.isConnected() == false) {
					return;
				}
				
				commandPacket[0] = SET_LED;
				commandPacket[1] = 0;
				
				accessoryManager.write(commandPacket);			
				break;
			case REQUEST_AD:
				if(accessoryManager.isConnected() == false) {
					return;
				}
				
				commandPacket[0] = REQUEST_AD;
				commandPacket[1] = 0;
				
				accessoryManager.write(commandPacket);			
				break;
			
			case USBAccessoryWhat:
				switch(((USBAccessoryManagerMessage)msg.obj).type) {
				case READ:
					if(accessoryManager.isConnected() == false) {
						return;
					}
					
					while(true) {
						if(accessoryManager.available() < 2) {
							//All of our commands in this example are 2 bytes.  If there are less
							//  than 2 bytes left, it is a partial command
							break;
						}
					
						accessoryManager.read(commandPacket);
						
						switch(commandPacket[0]) {
						case RESPONSE_AD:
							// 受信したAD値を計算 (3)
					    	TextView temp_text = (TextView)findViewById(R.id.temp);
					    	int ad = commandPacket[1] << 1;
					    	double t = ((3.3/1023)*ad-0.5)/0.01;
					    	DecimalFormat tFormat = new DecimalFormat("###");
					    	temp_text.setText(tFormat.format(t) + "゜");

							break;
						}
						
					}
					break;
				case CONNECTED:
					break;
				case READY:
					setTitle("Thermometer : Device connected.");
					
					Log.d(TAG, "BasicAccessoryDemo:Handler:READY");
				
					deviceAttached = true;
					commandPacket[0] = (byte) APP_CONNECT;
					commandPacket[1] = 0;
					Log.d(TAG,"sending connect message.");
					accessoryManager.write(commandPacket);
					Log.d(TAG,"connect message sent.");
					break;
				case DISCONNECTED:
					disconnectAccessory();
					break;
				}				
				
   				break;
			default:
				break;
			}	//switch
    	} //handleMessage
    }; //handler

    private void showErrorPage(ErrorMessageCode error)
    {	   	
    	switch(error){
	    	case ERROR_OPEN_ACCESSORY_FRAMEWORK_MISSING:
	    		Toast.makeText(this, getResources().getText(R.string.error_missing_open_accessory_framework), Toast.LENGTH_LONG).show();
	    		break;
    		default:
    			Toast.makeText(this,getResources().getText(R.string.error_default), Toast.LENGTH_LONG).show();
    			break;
    	}
    }    
}