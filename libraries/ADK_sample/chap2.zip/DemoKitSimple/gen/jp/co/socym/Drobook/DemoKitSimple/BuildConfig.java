/** Automatically generated file. DO NOT MODIFY */
package jp.co.socym.Drobook.DemoKitSimple;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}